<?php
add_theme_support( 'custom-logo' );
add_theme_support( 'menus' );